<?php
    require_once "database_connect.php";

    // Проверяем, был ли отправлен запрос на удаление бронирования
    if(isset($_POST['delete_reservation'])) {
        $reservation_id_to_delete = $_POST['reservation_id'];
        // Выполняем SQL-запрос для удаления бронирования с указанным идентификатором
        $query = "UPDATE Guests SET Populated = 0, Room = 0 WHERE ID = (SELECT IDguest FROM Reservations WHERE ID = ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $reservation_id_to_delete);
        $stmt->execute();
        $delete_query = "DELETE FROM Reservations WHERE id = $reservation_id_to_delete";
        if ($conn->query($delete_query) === TRUE) {
            echo "Бронирование успешно удалено";
            header("Location: index");
            exit();
        } else {
            echo "Ошибка при удалении бронирования: " . $conn->error;
        }
    } else {
        echo "Неверный запрос";
    }
?>
