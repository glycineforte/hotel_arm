<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Панель</title>
        <link rel="stylesheet" href="styles.css">
        <link rel="icon" href="https://www.polaradventures.de/wp-content/uploads/svg/Gaeste.svg" type="image/png">
        <script src="index.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="nav">
            <h3><a style="text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px; font-weight: 700;" href="/index">HostelERM</a></h3>    
                <div style="display: flex; flex-direction: row; column-gap: 25px; align-items: center;">
                    <a style="text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px; font-weight: 700;" href="/guests">Гости</a>
                    <a style="text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px; font-weight: 700;" href="/rooms">Номера</a>
                    <a style="text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px; font-weight: 700;" href="/categories">Категории</a>
                    <form action="logout.php" method="post">
                        <input style="width: 80px; height: 35px; border-radius: 5px; border: solid; font-weight: 700;" type="submit" value="Выйти">
                    </form> 
                </div>
            </div>
            <div style="text-align: center; margin-top: 70px; display: flex; flex-direction: row;align-items: center; align-content: center; justify-content: center;">
                <div class="form">
                    <form action="addReservation.php" method="post" style="height: 350px; width:100%; border-radius: 15px; border: solid;">
                        <div class="rowform" style="padding-top: 55px">
                            <p>На кого записать бронь: </p>
                            <select style="border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0;" name="IDguest">
                                <?php
                                    require_once "database_connect.php";
                                    $query = "SELECT ID, Name FROM Guests";
                                    $result = $conn->query($query);
                                    if ($result->num_rows > 0) {
                                        while($row = $result->fetch_assoc()) {
                                            echo "<option value='" . $row['ID'] . "'>" . $row['Name'] . "</option>";
                                        }
                                    } else {
                                        echo "<option value=''>Нет доступных гостей</option>";
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="rowform" style="display: flex; column-gap: 25px; row-gap: 16px;  margin-top: 15px;">
                            <div style="display: flex; flex-direction: column; align-items: center;">
                                <p>Заселение: </p><input style="margin-top: 5px; border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0;" id="start" type="date" min="<?php echo date('Y-m-d'); ?>" name="start">
                            </div>
                            <div style="display: flex; flex-direction: column; align-items: center;">
                                <p>Выселение: </p><input style="margin-top: 5px; border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0;" id="end" type="date" min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>" name="end">
                            </div>
                        </div>
                        <div class="rowform" style="margin-top: 15px">
                                    <p>Номер: </p>
                                    <select name="Room" onchange="fetchRoomPrice(this.value)" style="border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0;">
                                        <?php
                                            $query = "SELECT ID, number, type FROM Rooms"; // Добавлено поле Type
                                            $result = $conn->query($query);
                                            if ($result->num_rows > 0) {
                                                while($row = $result->fetch_assoc()) {
                                                    echo "<option value='" . $row['ID'] . "' data-type='" . $row['type'] . "'>" . $row['number'] . "</option>"; // Добавлено data-type для хранения типа
                                                }
                                            } else {
                                                echo "<option value=''>Нет доступных номеров</option>";
                                            }
                                        ?>
                                    </select>            
                        </div>
                        <div class="rowform" style="margin-top: 15px">
                            <button type="button" style="width: 80px; height: 35px; border-radius: 5px; border: solid;" onclick="calculatePrice()">Рассчитать</button>
                            <label for="price">Цена:</label>
                            <input type="text" style="border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0;" id="price" name="price" readonly>
                        </div>
                        <div class="rowform" style="padding-top: 15px">
                            <p>Кол-во гостей: </p><input style="border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0;" type="text" name="count">
                        </div>
                        <input id="addBtn" style="margin-top: 15px; margin-bottom: 25px; width: 70px; height: 35px; border-radius: 5px; border: solid;" type="submit" value="Добавить">
                        <?php 
                            if(array_key_exists('status', $_GET)){
                                $tmp = $_GET["status"];
                                echo "<script>alert('$tmp')</script>";
                            } 
                        ?>
                    </form>
                </div>
            
                <div id="Table" style="margin-left:45px; width:100%; border-radius: 15px; border: solid; height: 280px;">
                    <h3 style="padding-top: 35px; border-bottom: solid;">Список брони:</h3>
                    <?php
                        require_once "database_connect.php";

                        $query = "SELECT id, Who, Start, End, Room, Price, Count FROM Reservations";
                        $result = $conn->query($query);
                        

                        if ($result->num_rows > 0) {
                            echo "
                            
                            <div style='overflow: auto; width: 100%; height: 350px; margin-top: 15px; padding-bottom: 15px; overflow-x: hidden;'> <table>
                                <tr>
                                    <th>ID</th>
                                    <th>Ф.И.О.</th>
                                    <th>Заселение</th>
                                    <th>Выселение</th>
                                    <th>Комната</th>
                                    <th>Цена</th>
                                    <th>Количество гостей</th>
                                </tr>";

                            while($row = $result->fetch_assoc()) {
                                $t = $row['Room'];
                                $query1 = "SELECT number FROM Rooms WHERE ID = $t";
                                $result2 = $conn->query($query1);
                                $row2 = $result2->fetch_assoc();
                                $number = $row2['number'];
                                echo "
                                <tr>
                                    <td>".(isset($row['id']) ? $row['id'] : '')."</td>
                                    <td>".(isset($row['Who']) ? $row['Who'] : '')."</td>
                                    <td>".(isset($row['Start']) ? $row['Start'] : '')."</td>
                                    <td>".(isset($row['End']) ? $row['End'] : '')."</td>
                                    <td>".(isset($row['Room']) ? $number : '')."</td>
                                    <td>".(isset($row['Price']) ? $row['Price'] : '')."</td>
                                    <td>".(isset($row['Count']) ? $row['Count'] : '')."</td>
                                    <td>
                                        <form action='deleteRes.php' method='post'>
                                            <input type='hidden' name='reservation_id' value='{$row['id']}'>
                                            <input style='text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px;font-weight: 700;' type='submit' name='delete_reservation' value='Удалить'>
                                        </form>
                                    </td>
                                </tr>";
                            }

                            echo "</table></div>";
                        } else {
                            echo "<br><br><br><br>Брони нет.";
                        }
                    ?>
                </div>
            </div>
        </div>
        <?php
        // Проверяем, существует ли значение "active" в локальном хранилище и равно ли оно true
        echo "<script>";
        echo "if (!localStorage.getItem('active') || localStorage.getItem('active') != 'true') {";
        echo "    window.location.href = 'login.php';";
        echo "}";
        echo "</script>";
        ?>
    </body>
</html>