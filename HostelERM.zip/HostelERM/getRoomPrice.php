<?php
require_once "database_connect.php";

if (isset($_GET['roomType'])) {
    $roomType = $_GET['roomType'];

    $query = "SELECT price FROM Type WHERE ID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $roomType);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $price = $row['price'];
        echo json_encode(['price' => $price]);
    } else {
        echo json_encode(['price' => 'N/A']);
    }
} else {
    echo json_encode(['price' => 'N/A']);
}
?>
