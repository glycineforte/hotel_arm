<?php
// Подключаемся к базе данных
require_once "database_connect.php";

// Проверяем, что все необходимые данные переданы через POST
if(isset($_POST['IDguest'], $_POST['start'], $_POST['end'], $_POST['Room'], $_POST['count'])) {
    // Получаем данные из POST запроса
    $id_guest = $_POST['IDguest'];
    
    $start = $_POST['start'];
    $end = $_POST['end'];
    $room = $_POST['Room'];
    $count = $_POST['count'];

    // Вычисляем количество дней между началом и концом бронирования
    $start_date = new DateTime($start);
    $end_date = new DateTime($end);
    $interval = $start_date->diff($end_date);
    $num_nights = $interval->days;

    $query = "SELECT Name FROM Guests WHERE ID = $id_guest";
    $result = $conn->query($query);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $who = $row['Name'];
    } else {
        // Если тип номера не найден, установим цену за ночь в 0
        $price_per_night = 0;
    }
    
    $query = "SELECT name, price FROM Type WHERE ID = (SELECT Type FROM Rooms WHERE ID = $room)";
    $result = $conn->query($query);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $type = $row['name'];
        $price_per_night = $row['price'];
    } else {
        // Если тип номера не найден, установим цену за ночь в 0
        $price_per_night = 0;
    }

    $query2 = "SELECT prepare FROM Rooms WHERE ID = $room";
    $result2 = $conn->query($query2);
    $row2 = $result2->fetch_assoc();
    $type2 = $row2['prepare'];
    if ($type2 == "1"){
        $query1 = "SELECT Room FROM Reservations WHERE Room = $room";
        $result1 = $conn->query($query1);
        if ($result1->num_rows > 0) {
            header("Location: index?status=Занято");
        } else {
            $query = "UPDATE Guests SET Populated = 1, Room = (SELECT number FROM Rooms WHERE ID = $room) WHERE ID = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $id_guest);
            $stmt->execute();

            

            // Вычисляем общую цену бронирования
            $total_price = $price_per_night * $num_nights;

            // Подготавливаем и выполняем запрос на добавление бронирования в таблицу Reservations
            $query = $conn->prepare("INSERT INTO Reservations (IDguest, Who, Start, End, Room, Type, Price, Count) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $query->bind_param("isssiiii", $id_guest, $who, $start, $end, $room, $type, $total_price, $count);
            // echo $_POST['Room'];
            if ($query->execute()) {
                header("Location: index?status=Успешно");
            } else {
                echo "Ошибка при добавлении брони: " . $query->error;
            }
        }
    }else{
        header("Location: index?status=Не%20готово");
    }
} else {
        
        echo "Отсутствуют данные для добавления брони";
    }
?>
