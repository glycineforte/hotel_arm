<?php
// Подключение к базе данных
require_once "database_connect.php";

// Проверка, была ли отправлена форма
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Получение данных из формы
    $name = $_POST['name'];
    $price = $_POST['price'];
    $count = $_POST['count'];

    // SQL запрос для вставки новой категории в базу данных
    $query = "INSERT INTO Type (name, price, volume) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sii", $name, $price, $count);
    
    // Выполнение запроса
    if ($stmt->execute()) {
        // Если запрос выполнен успешно, перенаправляем на страницу с категориями
        header("Location: categories");
    } else {
        // Если возникла ошибка, выводим сообщение об ошибке
        echo "Error: " . $stmt->error;
    }

    // Закрытие запроса и соединения
    $stmt->close();
    $conn->close();
}
?>
