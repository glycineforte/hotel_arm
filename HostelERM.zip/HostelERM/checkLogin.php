<?php
require_once "database_connect.php";
    // Проверяем, была ли отправлена форма
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Получаем логин и пароль из формы
        $login = $_POST['login'];
        $password = $_POST['password'];

        // Выполняем запрос к базе данных, чтобы получить хэшированный пароль для данного логина
        // Предположим, что у вас есть соединение с базой данных $conn
        $query = "SELECT password FROM Admin WHERE login = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $login);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $hashed_password_from_db = $row['password'];

            // Сравниваем хэшированный пароль из базы данных с хэшированным паролем, введенным пользователем
            if ($password == $hashed_password_from_db) {
                // Если пароль совпадает, устанавливаем информацию в локальное хранилище и перенаправляем на панель управления
                echo "<script>";
                echo "localStorage.setItem('active', true);";
                echo "window.location.href = 'index';";
                echo "</script>";
                exit(); // Выходим из скрипта, чтобы избежать дальнейшего вывода HTML
            } else {
                echo "Неверный логин или пароль";
            }
        } else {
            echo "Неверный логин или пароль";
        }
    }
?>
