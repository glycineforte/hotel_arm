<?php
// Подключение к базе данных
    require_once "database_connect.php";

    // Получение данных из формы
    $number = $_POST['number'];
    $category = $_POST['category'];
    $status = $_POST['status'];
    $prepare = isset($_POST['prepare']) ? 1 : 0;

    // SQL запрос для сохранения нового номера в базу данных
    $query = "INSERT INTO Rooms (number, type, status, prepare) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssss", $number, $category, $status, $prepare);

    // Выполнение запроса
    if ($stmt->execute()) {
        header("Location: rooms"); // Перенаправляем на страницу со списком номеров
    } else {
        echo "Error: " . $conn->error;
    }

    // Закрытие соединения
    $conn->close();
?>
