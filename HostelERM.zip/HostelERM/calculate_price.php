<?php
// Подключаемся к базе данных
require_once "database_connect.php";

// Проверяем, были ли переданы все необходимые параметры
if (isset($_GET['roomId'], $_GET['startDate'], $_GET['endDate'])) {
    $roomId = $_GET['roomId'];
    $startDate = $_GET['startDate'];
    $endDate = $_GET['endDate'];

    // Получаем цену за ночь для выбранного номера из таблицы Rooms
    $query = "SELECT r.type, t.price FROM Rooms r INNER JOIN Type t ON r.type = t.ID WHERE r.ID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $roomId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $type = $row['type'];
        $pricePerNight = $row['price'];

        // Вычисляем разницу в днях между датами
        $startTimestamp = strtotime($startDate);
        $endTimestamp = strtotime($endDate);
        $difference = abs($endTimestamp - $startTimestamp);
        $daysDifference = ceil($difference / (60 * 60 * 24));

        // Вычисляем общую стоимость проживания
        $totalPrice = $daysDifference * $pricePerNight;

        // Возвращаем цену в ответе
        echo $totalPrice;
    } else {
        echo "Ошибка: Не удалось получить цену";
    }

    // Закрываем соединение с базой данных
    $stmt->close();
    $conn->close();
} else {
    echo "Ошибка: Недостаточно данных для расчета цены";
}
?>
