<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" href="https://www.polaradventures.de/wp-content/uploads/svg/Gaeste.svg" type="image/png">
    <script src="index.js"></script>
</head>
    <body>
        <div class="container">
            <div class="nav">
            <h3><a style="text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px; font-weight: 700;" href="/index">HostelERM</a></h3>    
                <div style="display: flex; flex-direction: row; column-gap: 25px; align-items: center;">
                    <a style="text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px; font-weight: 700;" href="/guests">Гости</a>
                    <a style="text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px; font-weight: 700;" href="/rooms">Номера</a>
                    <a style="text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px; font-weight: 700;" href="/categories">Категории</a>
                    <form action="logout.php" method="post">
                        <input style="width: 80px; height: 35px; border-radius: 5px; border: solid; font-weight: 700;" type="submit" value="Выйти">
                    </form> 
                </div>
            </div>
            <div class="app" style="margin-top: 70px;">
                <form action="processCategory.php" method="post" style="width: 100%; border-radius: 15px; border: solid;">
                    <div class="rowform" style="margin-top: 15px">
                        <label for="name">Наименование категории:</label>
                        <input type="text" style="border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0;" id="name" name="name">
                    </div>
                    <div class="rowform" style="margin-top: 15px">
                        <label for="price">Цена за ночь:</label>
                        <input type="number" style="border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0;" id="price" name="price">
                    </div>
                    <div class="rowform" style="margin-top: 15px">
                        <label for="count">Вместимость:</label>
                        <input type="number" style="border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0;" id="count" name="count">    
                    </div>
                    <div class="rowform">
                        <input type="submit" style="margin-top: 15px; margin-bottom: 15px; width: 70px; height: 35px; border-radius: 5px; border: solid;" value="Добавить">
                    </div>
                    
                </form>
                <div style='overflow: auto; width: 100%; height: 250px; margin-top: 25px; padding-bottom: 15px; overflow-x: hidden; border-radius: 15px; border: solid; display:flex;flex-direction: column; align-items: center;'>
                    <h3 style='margin-top: 25px; margin-bottom: 25px;'>Категория</h3>
                    <ul>
                        <?php
                        // Подключение к базе данных
                        require_once "database_connect.php";

                        // SQL запрос для получения всех категорий
                        $query = "SELECT * FROM Type";
                        $result = $conn->query($query);

                        // Проверка, есть ли результаты запроса
                        if ($result->num_rows > 0) {
                            // Вывод каждой категории в виде списка
                            while($row = $result->fetch_assoc()) {
                                echo "<li style='margin-top: 10px'>" . $row['name'] . " - Цена за ночь: " . $row['price'] . "| Вместимость: " . $row['volume'] . " гость.";
                                echo "<a style='text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px;font-weight: 700;' href='deleteCategory.php?id=" . $row['ID'] . "'>Удалить</a></li>";
                            }
                        } else {
                            echo "<br><br><br><br>Пусто";
                        }

                        // Закрытие соединения
                        $conn->close();
                        ?>
                    </ul>
                </div>
            </div>
        </div>
    </body>
</html>
