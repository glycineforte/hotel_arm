<?php

    $conn=new mysqli("localhost","root","","HostelERM");
    
    if(!$conn)
    {
        echo "Connection Is Not Available";
    }

?>