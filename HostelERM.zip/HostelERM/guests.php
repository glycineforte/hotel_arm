<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Список гостей</title>
    <link rel="icon" href="https://www.polaradventures.de/wp-content/uploads/svg/Gaeste.svg" type="image/png">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <div class="nav">
        <h3><a style="text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px; font-weight: 700;" href="/index">HostelERM</a></h3>    
            <div style="display: flex; flex-direction: row; column-gap: 25px; align-items: center;">
                <a style="text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px; font-weight: 700;" href="/guests">Гости</a>
                <a style="text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px; font-weight: 700;" href="/rooms">Номера</a>
                <a style="text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px; font-weight: 700;" href="/categories">Категории</a>
                <form action="logout.php" method="post">
                    <input style="width: 80px; height: 35px; border-radius: 5px; border: solid; font-weight: 700;" type="submit" value="Выйти">
                </form> 
            </div>
        </div>
        <div class="app" style="margin-top: 70px;">
            <form action="processGuest.php" method="post" style="width: 100%; border-radius: 15px; border: solid;">
                <div class="rowform" style="margin-top: 15px">
                    <label for="name">ФИО:</label>
                    <input type="text" style="border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0;" id="name" name="name" required>
                </div>
                <div class="rowform" style="margin-top: 15px">
                    <label for="passport">Паспортные данные:</label>
                    <input type="text" style="border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0;" id="passport" name="passport" required>
                </div>
                <div class="rowform" style="margin-top: 15px">
                    <label for="number">Номер телефона:</label>
                    <input type="text" style="border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0;" id="number" name="number" required>
                </div>
                <div class="rowform" style="margin-top: 15px">
                    <label for="age">Возраст:</label>
                    <input type="number" style="border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0;" id="age" name="age" required>
                </div>
                <div class="rowform" style="margin-top: 15px">
                    <label for="alone">Один:</label>
                    <select id="alone" style="border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0;" name="alone">
                        <option value="0">Нет</option>
                        <option value="1">Да</option>
                    </select>
                </div>
                <div class="rowform" style="margin-top: 15px">
                    <input type="submit" style="margin-bottom: 15px; width: 140px; height: 35px; border-radius: 5px; border: solid;" value="Добавить гостя">
                </div>
            </form>
            <div style='overflow: auto; width: 100%; height: 250px; margin-top: 15px; padding-bottom: 15px; overflow-x: hidden; border-radius: 15px; border: solid; display:flex;flex-direction: column; align-items: center;'>
                <table>
                    <tr>
                        <th>ID</th>
                        <th>ФИО</th>
                        <th>Паспортные данные</th>
                        <th>Номер телефона</th>
                        <th>Возраст</th>
                        <th>Заселен</th>
                        <th>Один</th>
                        <th>Номер</th>
                        <th>Действие</th> <!-- Добавляем столбец для кнопки "Удалить" -->
                    </tr>
                <?php
                // Подключаемся к базе данных
                require_once "database_connect.php";

                // Выполняем запрос к базе данных для получения списка гостей
                $query = "SELECT * FROM Guests";
                $result = $conn->query($query);

                // Проверяем, есть ли результаты запроса
                if ($result->num_rows > 0) {
                    // Выводим каждого гостя в таблицу
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['ID'] . "</td>";
                        echo "<td>" . $row['Name'] . "</td>";
                        echo "<td>" . $row['Passport'] . "</td>";
                        echo "<td>" . $row['Number'] . "</td>";
                        echo "<td>" . $row['Age'] . "</td>";
                        echo "<td>" . ($row['Populated'] ? "Да" : "Нет") . "</td>";
                        echo "<td>" . ($row['Alone'] ? "Да" : "Нет") . "</td>";
                        echo "<td>" . $row['Room'] . "</td>";
                        echo "<td><form action='deleteguest.php' method='post'>";
                        echo "<input type='hidden' name='guest_id' value='" . $row['ID'] . "'>";
                        echo "<input style='text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px;font-weight: 700;' type='submit' value='Удалить'></form></td>"; // Добавляем кнопку "Удалить" в форме
                        echo "</tr>";
                    }
                } else {
                    // Если нет гостей в базе данных, выводим сообщение
                    echo "<tr><td colspan='9'>Нет гостей</td></tr>";
                }

                // Закрываем соединение с базой данных
                $conn->close();
                ?>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
