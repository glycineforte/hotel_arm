<?php
// Проверяем, был ли отправлен POST-запрос
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Получаем данные гостя из формы
    $name = $_POST['name'];
    $passport = $_POST['passport'];
    $number = $_POST['number'];
    $age = $_POST['age'];
    $populated = "Нет";
    $alone = $_POST['alone'];
    $room = 0;

    // Подключаемся к базе данных
    require_once "database_connect.php";

    // Подготавливаем SQL-запрос для добавления гостя
    $query = "INSERT INTO Guests (Name, Passport, Number, Age, Populated, Alone, Room) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssssiii", $name, $passport, $number, $age, $populated, $alone, $room);

    // Выполняем запрос
    if ($stmt->execute()) {
        // Гость успешно добавлен, перенаправляем на страницу просмотра гостей
        header("Location: guests");
    } else {
        // Ошибка при выполнении запроса
        echo "Ошибка при добавлении гостя.";
    }

    // Закрываем соединение с базой данных
    $conn->close();
} else {
    // Если запрос не был отправлен методом POST, выводим сообщение об ошибке
    echo "Ошибка: Недопустимый метод запроса.";
}
?>
