function calculatePrice() {
    
    // Получаем выбранные значения
    var roomId = document.querySelector('select[name="Room"]').value;
    var startDate = document.getElementById('start').value;
    var endDate = document.getElementById('end').value;

    // Проверяем, что все необходимые данные заполнены
    if (roomId && startDate && endDate) {
        // Отправляем запрос на сервер для получения цены
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "calculate_price.php?roomId=" + roomId + "&startDate=" + startDate + "&endDate=" + endDate, true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // Обновляем значение поля "Цена"
                document.getElementById('price').value = xhr.responseText;
            }
        };
        xhr.send();
    } else {
        alert('Пожалуйста, заполните все поля');
    }
}

function fetchRoomPrice(roomId) {
    var roomSelect = document.querySelector('select[name="Room"]');
    var roomType = roomSelect.options[roomSelect.selectedIndex].getAttribute('data-type');

    // Отправить асинхронный запрос на сервер, чтобы получить цену для выбранного типа номера
    fetch('getRoomPrice.php?roomType=' + roomType)
        .then(response => response.json())
        .then(data => {
            // Обновить поле ввода цены на странице
            document.getElementById('price').value = data.price;
        })
        .catch(error => {
            console.error('Error:', error);
        });
}



function deleteReservation(reservationId) {
    // Отправляем AJAX-запрос на сервер для удаления бронирования
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "deleteRes.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                // Если удаление прошло успешно, обновляем страницу для обновления списка бронирований
                location.reload();
            } else {
                // Если произошла ошибка при удалении, выводим сообщение об ошибке
                alert("Ошибка при удалении бронирования: " + xhr.responseText);
            }
        }
    };
    xhr.send("id=" + reservationId);
}

