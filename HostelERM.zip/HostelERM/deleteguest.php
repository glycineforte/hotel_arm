<?php
// Подключаемся к базе данных
require_once "database_connect.php";

// Проверяем, был ли передан ID гостя для удаления
if(isset($_POST['guest_id']) && !empty($_POST['guest_id'])) {
    // Получаем ID гостя из запроса
    $id = $_POST['guest_id'];

    // Подготавливаем SQL запрос для удаления гостя
    $query = "DELETE FROM Guests WHERE ID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);

    // Выполняем запрос
    if ($stmt->execute()) {
        // Если запрос выполнен успешно, перенаправляем обратно на страницу списка гостей
        header("Location: guests.php");
    } else {
        // Если произошла ошибка при выполнении запроса, выводим сообщение об ошибке
        echo "Ошибка при удалении гостя: " . $conn->error;
    }
} else {
    // Если ID гостя не был передан, выводим сообщение об ошибке
    echo "ID гостя не был передан.";
}

// Закрываем соединение с базой данных
$conn->close();
?>
