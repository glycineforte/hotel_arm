<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Панель</title>
        <link rel="stylesheet" href="styles.css">
        <link rel="icon" href="https://www.polaradventures.de/wp-content/uploads/svg/Gaeste.svg" type="image/png">
        <script src="index.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="form" style="margin-top:170px;">
                <form action="checkLogin.php" style="width: 250px; border-radius: 15px; border: solid;" method="post">
                    <div style="margin-right: 10px; margin-left: 10px; width: 230px; padding-top: 25px; display: flex; align-items: center; justify-content: space-between;">
                        <p>Логин: </p><input style="border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0;" type="text" name="login" autofocus>
                    </div>
                    <div style="margin-right: 10px; margin-left: 10px; width: 230px; margin-top: 15px; display: flex; align-items: center; justify-content: space-between;">
                        <p>Пароль: </p><input style="border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0;" type="password" name="password">
                    </div>
                    <div style="display: flex; align-items: center; justify-content: center; margin-top: 25px; padding-bottom: 25px;" >
                        <input id="loginBTN" style="transition: transform 0.7s; width: 70px; height: 45px; border-radius: 5px; border: solid;" type="submit" value="Войти">
                    </div>
                </form>
            </div>
        </div>
        <?php
        // Проверяем, существует ли значение "active" в локальном хранилище и равно ли оно true
        echo "<script>";
        echo "if (localStorage.getItem('active') || localStorage.getItem('active') == 'true') {";
        echo "    window.location.href = 'index';";
        echo "}";
        echo "</script>";
        ?>
        
    </body>
</html>