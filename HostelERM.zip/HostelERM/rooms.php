<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель</title>
    <link rel="icon" href="https://www.polaradventures.de/wp-content/uploads/svg/Gaeste.svg" type="image/png">
    <link rel="stylesheet" href="styles.css">
    <script src="index.js"></script>
</head>
<body>
    <div class="container">
            <div class="nav">
            <h3><a style="text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px; font-weight: 700;" href="/index">HostelERM</a></h3>   
            <div style="display: flex; flex-direction: row; column-gap: 25px; align-items: center;">
                <a style="text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px; font-weight: 700;" href="/guests">Гости</a>
                <a style="text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px; font-weight: 700;" href="/rooms">Номера</a>
                <a style="text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px; font-weight: 700;" href="/categories">Категории</a>
                <form action="logout.php" method="post">
                    <input style="width: 80px; height: 35px; border-radius: 5px; border: solid; font-weight: 700;" type="submit" value="Выйти">
                </form> 
            </div>
        </div>
        <div class="app" style="margin-top: 50px">
            <form action="saveRoom.php" method="post" style="width: 100%; border-radius: 15px; border: solid;">
                <div class="rowform" >
                    <label for="number">Номер:</label>
                    <input type="text" class="underInput" id="number" name="number" required><br><br>
                </div>
                <div class="rowform" style="margin-top: 15px">
                    <label for="category">Категория:</label>
                    <select style="border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0;" name="category" id="category">
                        <?php
                        // Подключение к базе данных
                        require_once "database_connect.php";

                        // SQL запрос для получения всех категорий
                        $query = "SELECT * FROM Type";
                        $result = $conn->query($query);

                        // Проверка, есть ли результаты запроса
                        if ($result->num_rows > 0) {
                            // Вывод каждой категории в виде опций для выбора
                            while($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row['ID'] . "'>" . $row['name'] . "</option>";
                            }
                        } else {
                            echo "<option value=''>Категория ещё не созданы</option>";
                        }

                        ?>
                    </select>
                </div>
                <div class="rowform" style="margin-top: 15px">
                    <label for="status">Статус:</label>
                    <select style="border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0;" name="status" id="status">
                        <option value="Доступен">Доступен</option>
                        <option value="Занят">Занят</option>
                        <option value="Обслуживается">Обслуживается</option>
                    </select>
                </div>
                <div class="rowform" style="border: 0; border-bottom: 1px solid #000; background-color: rgba(0,0,0,0); outline: 0; margin-top: 15px">
                    <label for="prepare">Готовность:</label>
                    <input type="checkbox" id="prepare" name="prepare">
                </div>
                <input type="submit" value="Создать" style="margin-top: 15px; margin-bottom: 15px; width: 70px; height: 35px; border-radius: 5px; border: solid;">
            </form>
            
            <div style='overflow: auto; width: 100%; height: 250px; margin-top: 25px; padding-bottom: 15px; overflow-x: hidden; border-radius: 15px; border: solid; display:flex;flex-direction: column; align-items: center;'>
                <h3 style="margin-top: 15px">Список номеров:</h3>
                <?php
                require_once "database_connect.php";

                $query = "SELECT * FROM Rooms";
                $result = $conn->query($query);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<div style='display: flex; width: 100%;flex-direction: row; justify-content: space-evenly; margin-top: 25px'>Номер: " . $row['number'] . ", Категория: " . $row['type'] . ", Статус: " . $row['status'] . ", Готовность: " . ($row['prepare'] ? "Да" : "Нет") . " <form action='deleteRoom.php' method='post'><input type='hidden' name='room_id' value='" . $row['ID'] . "'><input style='text-decoration: none; color: black; border-bottom: solid; border-bottom-width:1,25px;font-weight: 700;' type='submit' value='Удалить'></form></div>";
                    }
                } else {
                    echo "<br><br>Номеров нет ещё.";
                }

                $conn->close();
                ?>
            </div>
        </div>
    </div>
</body>
</html>
