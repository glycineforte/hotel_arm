<?php
    // Удаляем значение "active" из локального хранилища
    echo "<script>";
    echo "localStorage.removeItem('active');";
    echo "window.location.href = 'login.php';";
    echo "</script>";
?>
